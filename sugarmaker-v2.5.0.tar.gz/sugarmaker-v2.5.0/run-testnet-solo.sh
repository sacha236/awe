./sugarmaker -a YespowerSugar -o http://104.200.24.172:34229 --no-longpoll -u user -p pass --coinbase-addr=sugar1qq49whq6jxyey9zeyp5s0xsl98nyg0wvvax3k6e
